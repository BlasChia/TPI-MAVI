#pragma once

#include <stdio.h>
#include <tchar.h>

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

using namespace sf;

class Mira {
	Texture txMira;
	Sprite spMira;

public:
	Mira() {
		txMira.loadFromFile("Assets/Mira.png");
		spMira.setTexture(txMira);
		spMira.setOrigin(180, 180);
		spMira.setScale(0.15, 0.15);
	}

	void Dibujar(RenderWindow* wnd) {
		wnd->draw(spMira);
	}

	void Posicionar(Vector2i posMouse) {
		spMira.setPosition(posMouse.x, posMouse.y);
	}

	Vector2f ObtPosicion() {
		return spMira.getPosition();
	}
};