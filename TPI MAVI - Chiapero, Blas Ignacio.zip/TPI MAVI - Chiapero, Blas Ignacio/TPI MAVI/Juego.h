#pragma once


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <time.h>
#include <string>

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#include "Mira.h"
#include "Enemigo.h"
#include "Rehen.h"


using namespace sf;

class Juego {

    RenderWindow* _wnd;

    Texture txMenu;
    Texture txFondoVac;
    Texture txFondo1;
    Texture txFondo2;
    Texture txFondo3;
    Texture txFondo4;
    Texture txFondo5;

    Texture txDisparo;
    Texture txPantFinal;

    Sprite spMenu;
    Sprite spFondo;
    Sprite spDisparo;
    Sprite spPantFinal;

    Vector2f* posAparicion[5];

    Mira* _mira;
    Enemigo* _enemigo;
    Rehen* _rehen;

    int _vidas, _derrotados;
    Text vidas, derrotados, puntajeFinal;
    Font fuente;

    sf::Clock tiempoDispEnem;
    sf::Clock tiempoEnPos;
    sf::Clock tiempoDisp;

    float _tiempoEnPant;

    float tiempoMaxSinObj;

    bool disparado, partidaTerminada, menu;

    void ActualizarPuntaje() {
        if (_vidas > 0) {
            vidas.setString("Vidas: " + std::to_string(_vidas));
        }
        else {
            vidas.setString("Vidas: " + std::to_string(_vidas));

            spFondo.setTexture(txFondoVac);
            partidaTerminada = true;

            puntajeFinal.setString(std::to_string(_derrotados * 100));
        }

        derrotados.setString("Derrotados: " + std::to_string(_derrotados));
    }

    void Menu() {

        menu = true;
        partidaTerminada = false;
        vidas.setString("");
        derrotados.setString("");
        puntajeFinal.setString("");
    }

    void PantFinal() {

        puntajeFinal.setString(std::to_string(_derrotados*100));
        puntajeFinal.setPosition(380, 500);
        
    }

public:
    Juego() {
       
        _wnd = new RenderWindow(VideoMode(900, 700), "Space Defender");
        _wnd->setMouseCursorVisible(false);
        _wnd->setFramerateLimit(60);

        _mira = new Mira();
        _rehen = new Rehen();
        _enemigo = new Enemigo(10);

        _vidas = 3;
        _derrotados = 0;

        tiempoEnPos.restart();

        _tiempoEnPant = 3;
        tiempoMaxSinObj = 3;

        txFondoVac.loadFromFile("Assets/FondoVac.jpg");
        txFondo1.loadFromFile("Assets/Fondo1.png");
        txFondo2.loadFromFile("Assets/Fondo2.png");
        txFondo3.loadFromFile("Assets/Fondo3.png");
        txFondo4.loadFromFile("Assets/Fondo4.png");
        txFondo5.loadFromFile("Assets/Fondo5.png");

        spFondo.setTexture(txFondoVac);

        posAparicion[0] = new Vector2f(165, 190);
        posAparicion[1] = new Vector2f(435, 190);
        posAparicion[2] = new Vector2f(725, 190);
        posAparicion[3] = new Vector2f(300, 430);
        posAparicion[4] = new Vector2f(585, 430);

        txDisparo.loadFromFile("Assets/Da�o.png");
        spDisparo.setTexture(txDisparo);
        disparado = false;

        txPantFinal.loadFromFile("Assets/PuntajeFinal.jpg");
        spPantFinal.setTexture(txPantFinal);
        partidaTerminada = false;

        txMenu.loadFromFile("Assets/Menu.jpg");
        spMenu.setTexture(txMenu);

        fuente.loadFromFile("Fuente/Sterion-BLLld.ttf");

        vidas.setPosition(50, 620);
        vidas.setFont(fuente);
        vidas.setCharacterSize(40.0f);

        derrotados.setPosition(440, 620);
        derrotados.setFont(fuente);
        derrotados.setCharacterSize(40.0f);

        puntajeFinal.setPosition(380, 500);
        puntajeFinal.setFont(fuente);
        puntajeFinal.setCharacterSize(60.0f);

        Menu();

        ActualizarPuntaje();
    }

    void LoopPrinc() {
        while (_wnd->isOpen()) {
            ProcesarEventos();
            Actualizar();
            Dibujar();
        }
    }

    void ProcesarEventos() {
        Event evt;
        while (_wnd->pollEvent(evt)) {
            switch (evt.type) {

            case Event::Closed:
                _wnd->close();
                break;

            case Event::MouseButtonPressed:
                if (evt.mouseButton.button == Mouse::Button::Left) {
                    if (menu) {
                        menu = false;
                        _vidas = 3;
                        _derrotados = 0;
                        ActualizarPuntaje();
                    }
                    else if (partidaTerminada) {
                        partidaTerminada = false;
                        Menu();
                    }
                    else {
                        DisparoJugador();
                    }
                }
                break;
            }
            if (Keyboard::isKeyPressed(Keyboard::Escape) == true)
                _wnd->close();
        }
    }

    void Actualizar() {
        if (!menu && !partidaTerminada) {
            _mira->Posicionar(sf::Mouse::getPosition(*_wnd));
            TiempoPosObj();

            if (!_enemigo->_fired) {
                DisparoEnem();
            }

            if (partidaTerminada)
                PantFinal();
        }
    }

    void DisparoJugador() {
        if (_enemigo->_atacando) {
            if (_enemigo->ChequearDisparo(_mira->ObtPosicion().x, _mira->ObtPosicion().y)) {
                spFondo.setTexture(txFondoVac);
                _enemigo->EstPosicion(Vector2f(0, 0));
                _enemigo->_atacando = false;
                _enemigo->_fired = true;

                tiempoEnPos.restart();

                _derrotados++;
            }
        }

        if (_rehen->seVe) {
            if (_rehen->ChequearDisparo(_mira->ObtPosicion().x, _mira->ObtPosicion().y)) {
                spFondo.setTexture(txFondoVac);
                _rehen->EstPosicion(Vector2f(0, 0));
                _rehen->seVe = false;

                tiempoEnPos.restart();

                _vidas--;
            }
        }

        ActualizarPuntaje();
    }

    void DisparoEnem() {
        if (tiempoDispEnem.getElapsedTime().asSeconds() > 1) {
            _enemigo->_fired = true;
            _vidas--;
            ActualizarPuntaje();

            spFondo.setTexture(txFondoVac);
            tiempoDisp.restart();
            disparado = true;
        }
    }

    void Dibujar() {
        _wnd->clear();

        if (menu) {
            _wnd->draw(spMenu);
        }
        else {

            if (_enemigo->_atacando) {
                _enemigo->Dibujar(_wnd);
            }

            if (_rehen->seVe) {
                _rehen->Dibujar(_wnd);
            }

            _wnd->draw(spFondo);

            if (partidaTerminada) {
                disparado = false;
                _wnd->draw(spPantFinal);
                _wnd->draw(puntajeFinal);
            }
            else {
                if (disparado && tiempoDisp.getElapsedTime().asSeconds() < 2) _wnd->draw(spDisparo);
            }
            
            _mira->Dibujar(_wnd);
            if (!partidaTerminada) {
                _wnd->draw(vidas);
                _wnd->draw(derrotados);
            }

        }

        _wnd->display();

    }

    void FondoYEnem() {
        ElegirObj();

        switch (NumeroRandom(0, 4))
        {
        case 0:
            spFondo.setTexture(txFondo1);
            _enemigo->EstPosicion(*posAparicion[0]);
            _rehen->EstPosicion(*posAparicion[0]);
            break;
        case 1:
            spFondo.setTexture(txFondo2);
            _enemigo->EstPosicion(*posAparicion[1]);
            _rehen->EstPosicion(*posAparicion[1]);
            break;
        case 2:
            spFondo.setTexture(txFondo3);
            _enemigo->EstPosicion(*posAparicion[2]);
            _rehen->EstPosicion(*posAparicion[2]);
            break;
        case 3:
            spFondo.setTexture(txFondo4);
            _enemigo->EstPosicion(*posAparicion[3]);
            _rehen->EstPosicion(*posAparicion[3]);
            break;
        case 4:
            spFondo.setTexture(txFondo5);
            _enemigo->EstPosicion(*posAparicion[4]);
            _rehen->EstPosicion(*posAparicion[4]);
            break;
        default:
            break;
        }
    }

    void TiempoPosObj() {
        if (!_enemigo->_atacando && !_rehen->seVe) {
            if (tiempoEnPos.getElapsedTime().asSeconds() > tiempoMaxSinObj) {
                tiempoEnPos.restart();
                FondoYEnem();

                disparado = false;
            }
        }
        else if (_enemigo->_atacando || _rehen->seVe) {
            if (tiempoEnPos.getElapsedTime().asSeconds() > _tiempoEnPant) {
                tiempoEnPos.restart();

                spFondo.setTexture(txFondoVac);

                _enemigo->EstPosicion(Vector2f(0, 0));
                _enemigo->_atacando = false;
                _enemigo->_fired = true;

                _rehen->EstPosicion(Vector2f(0, 0));
                _rehen->seVe = false;
            }
        }
    }

    int NumeroRandom(int min, int max) {
        int nRandom = (min + rand() % (max + 1 - min));
        return nRandom;
    }

    void ElegirObj() {
        switch (NumeroRandom(0, 3))
        {
        case 0:
            _enemigo = new Enemigo(0);
            _enemigo->_atacando = true;
            tiempoDispEnem.restart();
            _enemigo->_fired = false;

            _rehen->seVe = false;
            break;
        case 1:
            _enemigo = new Enemigo(1);
            _enemigo->_atacando = true;
            tiempoDispEnem.restart();
            _enemigo->_fired = false;

            _rehen->seVe = false;
            break;
        case 2:
            _enemigo = new Enemigo(2);
            _enemigo->_atacando = true;
            tiempoDispEnem.restart();
            _enemigo->_fired = false;

            _rehen->seVe = false;
            break;
        case 3:
            _rehen->seVe = true;
            _enemigo->_atacando = false;
            break;
        default:
            break;
        }
    }

    ~Juego() {
        delete _enemigo;
        delete _mira;
        delete _wnd;
    }
};