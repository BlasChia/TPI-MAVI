#include "Juego.h"

#define FONT_PATH "/Fuente/Sterion-BLLld.ttf"

using namespace sf;

int main() {
	
	srand(time(NULL));

	Juego juego;
	
	juego.LoopPrinc();

	return 0;
}