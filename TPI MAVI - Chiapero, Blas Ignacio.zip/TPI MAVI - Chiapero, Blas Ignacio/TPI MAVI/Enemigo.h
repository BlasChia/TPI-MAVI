#pragma once

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

class Enemigo {
	sf::Texture txEnemigo1;
	sf::Texture txEnemigo2;
	sf::Texture txEnemigo3;

	sf::Sprite spEnemigo;



public:
	Enemigo(int numeroText) {
		txEnemigo1.loadFromFile("assets/Enemigo1.png");
		txEnemigo2.loadFromFile("assets/Enemigo2.png");
		txEnemigo3.loadFromFile("assets/Enemigo3.png");

		//Colocamos la textura dependiendo del enemigo elegido
		switch (numeroText){

		case 0:
			spEnemigo.setTexture(txEnemigo1);
			break;

		case 1:
			spEnemigo.setTexture(txEnemigo2);
			break;

		case 2:
			spEnemigo.setTexture(txEnemigo3);
			break;

		default:
			break;

		}

		spEnemigo.setOrigin(32, 42);
		spEnemigo.setScale(2, 2);

		_atacando = false;
		_fired = true;
	}

	bool _atacando;
	bool _fired;

	bool ChequearDisparo(float x, float y) {
		sf::FloatRect bordes = spEnemigo.getGlobalBounds();
		return bordes.contains(x, y);
	}

	void Dibujar(sf::RenderWindow* wnd) {
		wnd->draw(spEnemigo);
	}

	bool EstaAtacando() {
		return _atacando;
	}

	void EstPosicion(sf::Vector2f posNueva) {
		spEnemigo.setPosition(posNueva);
	}
};
