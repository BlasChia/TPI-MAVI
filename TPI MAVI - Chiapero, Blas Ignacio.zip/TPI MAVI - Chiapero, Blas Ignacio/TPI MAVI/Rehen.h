#pragma once

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

class Rehen {
	sf::Texture txRehen;
	sf::Sprite spRehen;



public:
	Rehen() {
		txRehen.loadFromFile("Assets/Rehen.png");
		spRehen.setTexture(txRehen);
		spRehen.setOrigin(32, 42);
		spRehen.setScale(2, 2);

		seVe = false;
	}

	bool seVe;

	bool ChequearDisparo(float x, float y) {
		sf::FloatRect bordes = spRehen.getGlobalBounds();
		return bordes.contains(x, y);
	}

	void Dibujar(sf::RenderWindow* wnd) {
		wnd->draw(spRehen);
	}

	void EstPosicion(sf::Vector2f posNueva) {
		spRehen.setPosition(posNueva);
	}
};